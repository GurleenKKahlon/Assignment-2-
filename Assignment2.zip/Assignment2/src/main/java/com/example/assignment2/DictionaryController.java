package com.example.assignment2;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

public class DictionaryController {
    private final String apiUrl;
    private final String apiKey;

    public DictionaryController() {
        this.apiUrl = "https://api.api-ninjas.com/v1/dictionary?word=";
        this.apiKey = "TyGHUw98TZ6UJcrjRsUNG0IgYEzieLHLwrZe1RPI"; // Replace with your API key
    }

    public List<Word> searchWord(String word) {
        try {
            // Encode word for URL
            String encodedWord = URLEncoder.encode(word, StandardCharsets.UTF_8);
            String uri = apiUrl + encodedWord;

            // Create a URL object
            URL url = new URL(uri);

            // Create a connection object
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set request method
            connection.setRequestMethod("GET");

            // Set request headers
            connection.setRequestProperty("X-Api-Key", apiKey);

            // Get response code
            int responseCode = connection.getResponseCode();

            // Check if response code is OK (200)
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Read response
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Parse JSON response
                List<Word> words = parseWordData(response.toString());
                return words;
            } else {
                System.err.println("HTTP error: " + responseCode);
                return Collections.emptyList(); // Return empty list on HTTP error
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Collections.emptyList(); // Return empty list on exception
        }
    }

    private List<Word> parseWordData(String jsonString) {
        // Create a Gson instance for JSON parsing
        Gson gson = new Gson();
        // Use Gson to deserialize the JSON data into a list of Word objects
        return gson.fromJson(jsonString, new TypeToken<List<Word>>() {}.getType());
    }
}
