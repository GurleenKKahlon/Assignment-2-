package com.example.assignment2;

import com.google.gson.Gson;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

public class HttpRequestHelper {
    private static final String API_URL = "https://api.api-ninjas.com/v1/dictionary?word=";
    private static final String API_KEY = "TyGHUw98TZ6UJcrjRsUNG0IgYEzieLHLwrZe1RPI";

    public String getDefinition(String word) throws IOException {
        String encodedWord = URLEncoder.encode(word, StandardCharsets.UTF_8);
        String apiUrl = API_URL + encodedWord;

        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder(new URI(apiUrl))
                    .header("X-Api-Key", API_KEY)
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                return response.body();
            }
        } catch (URISyntaxException | InterruptedException e) {
            e.printStackTrace();
        }

        return null;
    }
}
