/**
 * com.games.gameexplorer package.
 */
package com.example.assignment2;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Main class for the Word Definition Lookup application.
 */
public class Main extends Application {
    private final HttpRequestHelper httpRequestHelper;

    /**
     * Constructor for the Main class.
     */
    public Main() {
        this.httpRequestHelper = new HttpRequestHelper();
    }

    /**
     * Start method for the application.
     * @param primaryStage The primary stage of the application.
     * @throws Exception Exception thrown if an error occurs.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        Label titleLabel = new Label("Word Definition Lookup");
        titleLabel.getStyleClass().add("titleLabel");

        Label searchLabel = new Label("Word:");
        searchLabel.getStyleClass().add("searchLabel");

        TextField searchField = new TextField();
        searchField.setPromptText("Enter a word");
        Button searchButton = new Button("Search");
        searchButton.getStyleClass().add("searchButton");

        Label definitionLabel = new Label();
        definitionLabel.getStyleClass().add("definitionLabel");
        definitionLabel.setWrapText(true);

        searchButton.setOnAction(event -> {
            String word = searchField.getText().trim();

            if (!word.isEmpty()) {
                try {
                    // Call API to fetch word definition
                    String definition = httpRequestHelper.getDefinition(word);

                    if (definition != null) {
                        // Display word definition
                        definitionLabel.setText(definition);
                    } else {
                        definitionLabel.setText("Definition not found.");
                    }
                } catch (IOException e) {
                    System.err.println("Error fetching data from API: " + e.getMessage());
                    definitionLabel.setText("Error fetching word definition.");
                }
            }
        });

        // Layout
        VBox mainVBox = new VBox(20);
        mainVBox.setAlignment(Pos.CENTER);
        mainVBox.setStyle("-fx-background-color: #f0f0f0; -fx-padding: 20px;");
        mainVBox.getChildren().addAll(titleLabel, createSearchBox(searchLabel, searchField, searchButton), definitionLabel);

        Scene scene = new Scene(mainVBox, 800, 600);
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setTitle("Word Definition Lookup");
        primaryStage.show();
    }

    /**
     * Method to create the search box.
     * @param searchLabel The label for the search box.
     * @param searchField The text field for entering the search term.
     * @param searchButton The button to initiate the search.
     * @return The HBox containing the search components.
     */
    private HBox createSearchBox(Label searchLabel, TextField searchField, Button searchButton) {
        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER);
        searchBox.getChildren().addAll(searchLabel, searchField, searchButton);
        return searchBox;
    }

    /**
     * Main method to launch the application.
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
