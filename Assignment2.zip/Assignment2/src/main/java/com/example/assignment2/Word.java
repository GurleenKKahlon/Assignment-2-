package com.example.assignment2;


public class Word {
    private String word;
    private String definition;
    private boolean valid;

    // Constructors
    public Word(String word, String definition, boolean valid) {
        this.word = word;
        this.definition = definition;
        this.valid = valid;
    }

    public Word(String word) {
        this.word = word;
    }

    // Getters and Setters

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    @Override
    public String toString() {
        return "Word{" +
                "word='" + word + '\'' +
                ", definition='" + definition + '\'' +
                ", valid=" + valid +
                '}';
    }
}
